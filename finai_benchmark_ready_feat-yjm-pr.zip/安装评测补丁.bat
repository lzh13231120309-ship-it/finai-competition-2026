@echo off
chcp 65001 >nul
setlocal

set "ROOT=%~dp0"
set "PY=%ROOT%runtime\python\Scripts\python.exe"

if exist "%PY%" (
  "%PY%" -X utf8 "%ROOT%install_benchmark_patch.py" %*
  exit /b %errorlevel%
)

where py >nul 2>nul
if not errorlevel 1 (
  py -3 -X utf8 "%ROOT%install_benchmark_patch.py" %*
  exit /b %errorlevel%
)

python -X utf8 "%ROOT%install_benchmark_patch.py" %*
exit /b %errorlevel%
