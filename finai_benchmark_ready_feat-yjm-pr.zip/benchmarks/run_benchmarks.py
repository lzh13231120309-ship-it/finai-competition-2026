from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import inspect
import json
import math
import os
import random
import re
import shutil
import statistics
import sys
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Iterator

import httpx

ROOT = Path(__file__).resolve().parent.parent
BENCH_DIR = Path(__file__).resolve().parent
DATA_DIR = BENCH_DIR / "data"
VENDOR_DIR = BENCH_DIR / "vendor"
RESULTS_DIR = BENCH_DIR / "results"
LATEST_FILE = RESULTS_DIR / "LATEST"

DEFAULT_SERVER = "http://127.0.0.1:17904"
DEFAULT_REQUEST_TIMEOUT = 600.0
DEFAULT_SEED = 20261011

SECQUE_REPO = "nogabenyoash/SecQue"
SECQUE_FILES = [
    "SECQUE_benchmark_Analysis.jsonl",
    "SECQUE_benchmark_Comparison.jsonl",
    "SECQUE_benchmark_Ratio.jsonl",
    "SECQUE_benchmark_Risk.jsonl",
]
T2_REPO = "G4KMU/t2-ragbench"
T2_FILES = {
    "FinQA": "data/FinQA/test/metadata.jsonl",
    "ConvFinQA": "data/ConvFinQA/turn_0.jsonl",
    "TAT-DQA": "data/TAT-DQA/test/metadata.jsonl",
}
FINCHAIN_ZIP = "https://github.com/mbzuai-nlp/finchain/archive/refs/heads/main.zip"

SECQUE_GRADER_TEMPLATE = """Your job is to evaluate whether the predicted answer is correct given the reference answer from financial experts.

The predicted answer should contain the same key financial information, numerical values (allowing for reasonable rounding), and logical conclusions as the reference answer. Minor formatting or wording differences are acceptable.
Provide a brief analysis paragraph explaining your reasoning, then conclude with either \"CORRECT\" or \"INCORRECT\".

Question: {question}
Reference Answer: {correct_answer}
Predicted Answer: {predicted_answer}
"""


@dataclass(frozen=True)
class BenchCase:
    case_id: str
    suite: str
    category: str
    prompt: str
    gold: str
    question: str
    metadata: dict[str, Any]
    tools: tuple[str, ...] = ()


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    VENDOR_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)


def read_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSONL: {path}:{line_no}: {exc}") from exc
            if not isinstance(obj, dict):
                raise ValueError(f"Expected JSON object: {path}:{line_no}")
            yield obj


def append_jsonl(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")
        f.flush()


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def stable_int(text: str, low: int = 1_000_000_000, span: int = 3_000_000_001) -> int:
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    return low + int.from_bytes(digest[:8], "big") % span


def download_hf_file(repo_id: str, filename: str, local_root: Path) -> Path:
    try:
        from huggingface_hub import hf_hub_download
    except ImportError as exc:
        raise RuntimeError("缺少 huggingface_hub；请先运行仓库根目录的 安装环境.bat") from exc
    path = hf_hub_download(
        repo_id=repo_id,
        repo_type="dataset",
        filename=filename,
        local_dir=str(local_root),
    )
    return Path(path)


def download_file(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    with httpx.stream("GET", url, follow_redirects=True, timeout=120.0) as resp:
        resp.raise_for_status()
        with tmp.open("wb") as f:
            for chunk in resp.iter_bytes():
                f.write(chunk)
    tmp.replace(dest)


def prepare_finchain(force: bool = False) -> Path:
    target = VENDOR_DIR / "finchain"
    if target.exists() and not force:
        return target
    if target.exists():
        shutil.rmtree(target)
    zip_path = VENDOR_DIR / "finchain-main.zip"
    if force or not zip_path.exists():
        print("[prepare] downloading FinChain...")
        download_file(FINCHAIN_ZIP, zip_path)
    temp = VENDOR_DIR / "_finchain_extract"
    if temp.exists():
        shutil.rmtree(temp)
    temp.mkdir(parents=True)
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(temp)
    roots = [p for p in temp.iterdir() if p.is_dir()]
    if len(roots) != 1:
        raise RuntimeError(f"FinChain archive layout changed: {roots}")
    shutil.move(str(roots[0]), str(target))
    shutil.rmtree(temp, ignore_errors=True)
    return target


def cmd_prepare(args: argparse.Namespace) -> int:
    ensure_dirs()
    print("[prepare] SECQUE")
    for filename in SECQUE_FILES:
        p = download_hf_file(SECQUE_REPO, filename, DATA_DIR / "secque")
        print(f"  ok {p.relative_to(BENCH_DIR)}")
    print("[prepare] T²-RAGBench metadata only (no PDF corpus)")
    for subset, filename in T2_FILES.items():
        p = download_hf_file(T2_REPO, filename, DATA_DIR / "t2")
        print(f"  ok {subset}: {p.relative_to(BENCH_DIR)}")
    p = prepare_finchain(force=args.force)
    print(f"[prepare] FinChain ok: {p.relative_to(BENCH_DIR)}")
    sources = {
        "prepared_at": datetime.now().astimezone().isoformat(),
        "secque": {"repo": SECQUE_REPO, "files": SECQUE_FILES},
        "t2_ragbench": {"repo": T2_REPO, "files": T2_FILES},
        "finchain": {"url": FINCHAIN_ZIP},
    }
    write_json(DATA_DIR / "sources.json", sources)
    print("[prepare] done")
    return 0


def require_file(path: Path, hint: str = "请先运行：评测.bat prepare") -> Path:
    if not path.is_file():
        raise FileNotFoundError(f"缺少 {path}\n{hint}")
    return path


def secque_cases(profile: str) -> list[BenchCase]:
    rows: list[dict[str, Any]] = []
    for filename in SECQUE_FILES:
        path = require_file(DATA_DIR / "secque" / filename)
        rows.extend(read_jsonl(path))
    rows.sort(key=lambda r: str(r.get("QID") or r.get("id") or ""))

    if profile == "smoke":
        by_type: dict[str, list[dict[str, Any]]] = {}
        for row in rows:
            category = str(row.get("question_type") or "Unknown")
            by_type.setdefault(category, []).append(row)
        selected: list[dict[str, Any]] = []
        for category in sorted(by_type):
            selected.extend(by_type[category][:4])
        rows = selected

    out: list[BenchCase] = []
    for idx, row in enumerate(rows):
        question = str(row.get("Question") or "").strip()
        context = str(row.get("context_markdown_with_headers") or "").strip()
        gold = str(row.get("ground_truth_answer") or "").strip()
        qid = str(row.get("QID") or row.get("id") or f"row-{idx}")
        category = str(row.get("question_type") or "Unknown")
        prompt = (
            "# Financial Analysis Question\n\n"
            f"{question}\n"
            "## SEC Filing Context\n\n"
            f"{context}\n\n"
            "Please analyze the context and provide a detailed answer to the question."
        )
        out.append(BenchCase(
            case_id=f"secque:{category}:{qid}", suite="secque", category=category,
            prompt=prompt, gold=gold, question=question,
            metadata={"qid": qid, "question_type": category}, tools=(),
        ))
    return out


def _load_module(path: Path):
    name = "finchain_" + hashlib.sha1(str(path).encode("utf-8")).hexdigest()
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _template_functions(module: Any) -> list[Any]:
    funcs = []
    for name, obj in inspect.getmembers(module, inspect.isfunction):
        if name.startswith("template_") and obj.__module__ == module.__name__:
            funcs.append(obj)
    funcs.sort(key=lambda f: (inspect.getsourcelines(f)[1], f.__name__))
    return funcs


def finchain_cases(profile: str) -> list[BenchCase]:
    root = VENDOR_DIR / "finchain" / "data" / "templates"
    if not root.is_dir():
        raise FileNotFoundError(f"缺少 FinChain templates：{root}\n请先运行：评测.bat prepare")
    modules = sorted(p for p in root.rglob("*.py") if p.name != "__init__.py")
    all_cases: list[BenchCase] = []
    repeats = 1  # quick = 1 deterministic seed per template
    for path in modules:
        rel = path.relative_to(root)
        domain = rel.parts[0] if len(rel.parts) > 1 else "unknown"
        topic = path.stem
        try:
            module = _load_module(path)
        except Exception as exc:
            print(f"[warn] skip FinChain module {rel}: {type(exc).__name__}: {exc}", file=sys.stderr)
            continue
        funcs = _template_functions(module)
        for fn_index, fn in enumerate(funcs, 1):
            doc = (inspect.getdoc(fn) or "").strip()
            parts = [p.strip() for p in doc.split(":", 2)]
            template_id = parts[0] if parts and parts[0] else str(fn_index)
            level = parts[1] if len(parts) >= 2 and parts[1] else "Unknown"
            for rep in range(repeats):
                key = f"{rel.as_posix()}::{fn.__name__}::{rep}"
                seed = stable_int(key)
                state = random.getstate()
                try:
                    random.seed(seed)
                    question, solution = fn()
                finally:
                    random.setstate(state)
                prompt = (
                    "Solve the following financial reasoning problem. "
                    "Use the calculator tool for arithmetic when useful. "
                    "Show concise key steps. End your response with exactly one line in this form:\n"
                    "FINAL_ANSWER: <single numeric value>\n\n"
                    f"Question:\n{question}"
                )
                all_cases.append(BenchCase(
                    case_id=f"finchain:{domain}:{topic}:t{template_id}:r{rep}",
                    suite="finchain", category=level,
                    prompt=prompt, gold=str(solution), question=str(question),
                    metadata={
                        "domain": domain, "topic": topic, "template_id": template_id,
                        "template_function": fn.__name__, "level": level, "seed": seed,
                        "source_file": rel.as_posix(),
                    },
                    tools=("calculator",),
                ))

    all_cases.sort(key=lambda c: c.case_id)
    if profile == "smoke":
        # Stable spread across the generated set, rather than taking only one domain.
        if len(all_cases) > 20:
            step = len(all_cases) / 20
            indices = sorted({min(int(i * step), len(all_cases) - 1) for i in range(20)})
            all_cases = [all_cases[i] for i in indices]
    return all_cases


def _deterministic_sample(rows: list[dict[str, Any]], n: int, salt: str) -> list[dict[str, Any]]:
    if len(rows) <= n:
        return rows
    rng = random.Random(stable_int(salt, low=0, span=2**31 - 1))
    idx = sorted(rng.sample(range(len(rows)), n))
    return [rows[i] for i in idx]


def t2_cases(profile: str) -> list[BenchCase]:
    out: list[BenchCase] = []
    per_subset = 5 if profile == "smoke" else 100
    for subset, filename in T2_FILES.items():
        path = require_file(DATA_DIR / "t2" / filename)
        rows = list(read_jsonl(path))
        rows = _deterministic_sample(rows, per_subset, f"t2:{subset}:{DEFAULT_SEED}")
        for i, row in enumerate(rows):
            question = str(row.get("question") or "").strip()
            context = str(row.get("context") or "").strip()
            gold = str(row.get("program_answer") or row.get("original_answer") or "").strip()
            rid = str(row.get("id") or f"row-{i}")
            prompt = (
                "Use only the financial report context below to answer the numerical question. "
                "Use the calculator tool for arithmetic when useful. "
                "Show concise key steps. End your response with exactly one line in this form:\n"
                "FINAL_ANSWER: <single numeric value>\n\n"
                f"Question:\n{question}\n\n"
                f"Financial report context:\n{context}"
            )
            out.append(BenchCase(
                case_id=f"t2:{subset}:{rid}", suite="t2", category=subset,
                prompt=prompt, gold=gold, question=question,
                metadata={
                    "subset": subset,
                    "row_id": rid,
                    "context_id": row.get("context_id"),
                    "split": row.get("split"),
                    "file_name": row.get("file_name"),
                    "original_answer": row.get("original_answer"),
                },
                tools=("calculator",),
            ))
    out.sort(key=lambda c: c.case_id)
    return out


def build_cases(suite: str, profile: str) -> list[BenchCase]:
    suites = [suite] if suite != "all" else ["secque", "finchain", "t2"]
    out: list[BenchCase] = []
    for name in suites:
        if name == "secque":
            out.extend(secque_cases(profile))
        elif name == "finchain":
            out.extend(finchain_cases(profile))
        elif name == "t2":
            out.extend(t2_cases(profile))
        else:
            raise ValueError(f"Unknown suite: {name}")
    return out


def server_health(server: str) -> dict[str, Any]:
    url = server.rstrip("/") + "/api/health"
    with httpx.Client(timeout=20.0) as client:
        resp = client.get(url)
        resp.raise_for_status()
        return resp.json()


def cmd_doctor(args: argparse.Namespace) -> int:
    try:
        health = server_health(args.server)
    except Exception as exc:
        print(f"[doctor] FAIL: cannot reach {args.server}: {type(exc).__name__}: {exc}")
        return 2
    print(json.dumps(health, ensure_ascii=False, indent=2))
    if not health.get("ok"):
        print("[doctor] FAIL: health.ok is false")
        return 2
    if not health.get("benchmark_api"):
        print("[doctor] FAIL: benchmark_api missing/false. Apply the README app.py + agent.py patch and restart 衡知.")
        return 2
    if not health.get("model"):
        print("[doctor] FAIL: no model selected")
        return 2
    if health.get("provider") == "local_finance" and health.get("local_model_ready") is False:
        print("[doctor] FAIL: local model is not ready")
        return 2
    print("[doctor] PASS")
    return 0


def parse_sse_lines(lines: Iterable[str]) -> Iterator[dict[str, Any]]:
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith(":"):
            continue
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if not payload:
            continue
        try:
            obj = json.loads(payload)
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict):
            yield obj


def run_one_case(server: str, case: BenchCase, timeout: float) -> dict[str, Any]:
    base = server.rstrip("/")
    started = time.perf_counter()
    task_id = None
    events: list[dict[str, Any]] = []
    tool_calls: list[dict[str, Any]] = []
    answer = ""
    usage: dict[str, Any] = {}
    partial = False
    status = "error"
    error = ""
    try:
        timeout_cfg = httpx.Timeout(timeout, connect=min(30.0, timeout))
        with httpx.Client(timeout=timeout_cfg) as client:
            r = client.post(base + "/api/tasks", json={"title": "BENCH " + case.case_id[:80]})
            r.raise_for_status()
            payload = r.json()
            task_id = str((payload.get("task") or {}).get("id") or "")
            if not task_id:
                raise RuntimeError(f"task create response missing id: {payload}")
            body = {
                "task_id": task_id,
                "content": case.prompt,
                "attachments": [],
                "benchmark_mode": True,
                "benchmark_tools": list(case.tools),
            }
            with client.stream("POST", base + "/api/chat", json=body) as resp:
                resp.raise_for_status()
                for ev in parse_sse_lines(resp.iter_lines()):
                    et = ev.get("type")
                    if et in {"tool_start", "tool_end", "done", "error", "cancelled"}:
                        events.append(ev)
                    if et == "tool_start":
                        tool_calls.append({
                            "name": ev.get("name"), "args": ev.get("args"),
                            "step": ev.get("step"), "id": ev.get("id"),
                        })
                    elif et == "done":
                        answer = str(ev.get("text") or (ev.get("message") or {}).get("content") or "")
                        usage = ev.get("usage") or {}
                        partial = bool(ev.get("partial"))
                        status = "partial" if partial else "done"
                    elif et == "error":
                        error = str(ev.get("error") or "unknown error")
                    elif et == "cancelled":
                        error = "cancelled"
            if status == "error" and not error:
                error = "stream ended without done event"
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    finally:
        if task_id:
            try:
                with httpx.Client(timeout=20.0) as cleanup:
                    cleanup.delete(base + f"/api/tasks/{task_id}")
            except Exception:
                pass
    latency = time.perf_counter() - started
    return {
        "case_id": case.case_id,
        "suite": case.suite,
        "category": case.category,
        "question": case.question,
        "gold": case.gold,
        "prediction": answer,
        "metadata": case.metadata,
        "status": status,
        "error": error,
        "partial": partial,
        "latency_sec": round(latency, 4),
        "usage": usage,
        "tool_calls": tool_calls,
        "event_tail": events[-12:],
    }


def completed_ids(path: Path) -> set[str]:
    if not path.is_file():
        return set()
    out = set()
    for row in read_jsonl(path):
        cid = row.get("case_id")
        if cid and row.get("status") in {"done", "partial"}:
            out.add(str(cid))
    return out


def new_run_id(profile: str, suite: str) -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S") + f"-{profile}-{suite}"


def resolve_run_dir(run_arg: str) -> Path:
    if run_arg == "latest":
        if not LATEST_FILE.is_file():
            raise FileNotFoundError("没有 latest run；请先运行 benchmark")
        name = LATEST_FILE.read_text(encoding="utf-8").strip()
        return RESULTS_DIR / name
    p = Path(run_arg)
    if p.is_absolute() or p.exists():
        return p.resolve()
    return RESULTS_DIR / run_arg


def cmd_run(args: argparse.Namespace) -> int:
    ensure_dirs()
    health = server_health(args.server)
    if not health.get("benchmark_api"):
        print("[run] benchmark_api not available. Apply README patch and restart 衡知.", file=sys.stderr)
        return 2
    cases = build_cases(args.suite, args.profile)
    if args.limit is not None:
        cases = cases[:max(0, args.limit)]
    run_id = args.run_id or new_run_id(args.profile, args.suite)
    run_dir = RESULTS_DIR / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    out_path = run_dir / "predictions.jsonl"
    done = completed_ids(out_path) if args.resume else set()
    pending = [c for c in cases if c.case_id not in done]
    metadata = {
        "run_id": run_id,
        "created_at": datetime.now().astimezone().isoformat(),
        "suite": args.suite,
        "profile": args.profile,
        "server": args.server,
        "case_count": len(cases),
        "already_done": len(done & {c.case_id for c in cases}),
        "health": health,
        "workers": args.workers,
        "timeout": args.timeout,
    }
    write_json(run_dir / "run.json", metadata)
    LATEST_FILE.write_text(run_id, encoding="utf-8")
    print(f"[run] {run_id}: {len(cases)} cases, pending {len(pending)}, workers={args.workers}")
    if not pending:
        print("[run] nothing to do")
        return 0

    finished = 0
    errors = 0
    if args.workers <= 1:
        for case in pending:
            row = run_one_case(args.server, case, args.timeout)
            append_jsonl(out_path, row)
            finished += 1
            errors += int(row["status"] not in {"done", "partial"})
            print(f"[{finished}/{len(pending)}] {case.case_id} -> {row['status']} ({row['latency_sec']:.1f}s)")
    else:
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = {pool.submit(run_one_case, args.server, c, args.timeout): c for c in pending}
            for fut in as_completed(futures):
                case = futures[fut]
                try:
                    row = fut.result()
                except Exception as exc:
                    row = {
                        "case_id": case.case_id, "suite": case.suite, "category": case.category,
                        "question": case.question, "gold": case.gold, "prediction": "",
                        "metadata": case.metadata, "status": "error",
                        "error": f"worker {type(exc).__name__}: {exc}", "partial": False,
                        "latency_sec": 0.0, "usage": {}, "tool_calls": [], "event_tail": [],
                    }
                append_jsonl(out_path, row)
                finished += 1
                errors += int(row["status"] not in {"done", "partial"})
                print(f"[{finished}/{len(pending)}] {case.case_id} -> {row['status']} ({row['latency_sec']:.1f}s)")
    print(f"[run] complete. errors={errors}. results={out_path}")
    return 0 if errors == 0 else 1


_NUM_TOKEN = re.compile(
    r"(?<![A-Za-z0-9_])(?P<paren>\()?\s*(?P<sign>[+-]?)\s*(?:[$€£¥￥]\s*)?"
    r"(?P<num>(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?|\.\d+)"
    r"\s*(?P<suffix>%|percent|percentage|billion|million|thousand|bn|mn|k)?\s*(?(paren)\))",
    re.IGNORECASE,
)


def parse_number_token(text: str) -> float | None:
    m = _NUM_TOKEN.search(text)
    if not m:
        return None
    value = float(m.group("num").replace(",", ""))
    sign = -1.0 if m.group("sign") == "-" else 1.0
    if m.group("paren"):
        sign = -1.0
    suffix = (m.group("suffix") or "").lower()
    mult = 1.0
    if suffix in {"billion", "bn"}:
        mult = 1e9
    elif suffix in {"million", "mn"}:
        mult = 1e6
    elif suffix in {"thousand", "k"}:
        mult = 1e3
    return sign * value * mult


def extract_final_number(text: str) -> float | None:
    if not isinstance(text, str) or not text.strip():
        return None
    final_lines = [ln for ln in text.splitlines() if re.search(r"FINAL[_ ]ANSWER\s*:", ln, re.I)]
    if final_lines:
        rhs = re.split(r"FINAL[_ ]ANSWER\s*:", final_lines[-1], flags=re.I, maxsplit=1)[-1]
        v = parse_number_token(rhs)
        if v is not None:
            return v
    matches = list(_NUM_TOKEN.finditer(text))
    if not matches:
        return None
    m = matches[-1]
    return parse_number_token(m.group(0))


def finchain_fac_lite(prediction: str, gold_trace: str, rel_tol: float = 0.05) -> tuple[bool | None, float | None, float | None]:
    pred = extract_final_number(prediction)
    gold = extract_final_number(gold_trace)
    if pred is None or gold is None:
        return None, pred, gold
    denom = abs(gold) + 1e-4
    ok = abs(gold - pred) / denom < rel_tol
    return ok, pred, gold


def t2_number_match(prediction: str, gold_text: str, eps: float = 1e-2) -> tuple[bool | None, float | None, float | None]:
    pred = extract_final_number(prediction)
    gold = extract_final_number(gold_text)
    if pred is None or gold is None:
        return None, pred, gold
    a_star, a = abs(pred), abs(gold)
    if a_star < eps and a < eps:
        return True, pred, gold
    if a_star == 0 or a == 0:
        return False, pred, gold
    ratio = a_star / a
    q = ratio * (10 ** (-round(math.log10(ratio))))
    return abs(q - 1.0) < eps, pred, gold


def secque_judge(question: str, gold: str, prediction: str, model: str, client: Any) -> tuple[bool, str]:
    prompt = SECQUE_GRADER_TEMPLATE.format(
        question=question, correct_answer=gold, predicted_answer=prediction
    )
    last_exc: Exception | None = None
    for attempt in range(3):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                stream=False,
            )
            text = response.choices[0].message.content or ""
            upper = text.upper()
            return ("CORRECT" in upper and "INCORRECT" not in upper), text
        except Exception as exc:
            last_exc = exc
            if attempt < 2:
                time.sleep(2 ** attempt)
    assert last_exc is not None
    raise last_exc


def _mean_percent(values: list[bool]) -> float | None:
    if not values:
        return None
    return 100.0 * sum(1 for x in values if x) / len(values)


def _safe_median(values: list[float]) -> float | None:
    return float(statistics.median(values)) if values else None


def _score_groups(rows: list[dict[str, Any]], key: str) -> dict[str, dict[str, Any]]:
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(str(row.get(key) or "Unknown"), []).append(row)
    result = {}
    for name, items in sorted(groups.items()):
        scored = [bool(x["correct"]) for x in items if x.get("correct") is not None]
        result[name] = {
            "n": len(items), "scored": len(scored), "accuracy_pct": _mean_percent(scored)
        }
    return result


def score_run(run_dir: Path, judge_secque: bool, judge_model: str) -> dict[str, Any]:
    pred_path = require_file(run_dir / "predictions.jsonl", "指定 run 中没有 predictions.jsonl")
    raw_rows = list(read_jsonl(pred_path))
    # A resumed run may contain an earlier failed attempt followed by a successful retry.
    # Keep only the latest record per case_id.
    latest_by_id: dict[str, dict[str, Any]] = {}
    for row in raw_rows:
        latest_by_id[str(row.get("case_id") or f"__row_{len(latest_by_id)}")] = row
    rows = list(latest_by_id.values())
    secque_cache_path = run_dir / "secque_judgments.jsonl"
    cached_judges = {r["case_id"]: r for r in read_jsonl(secque_cache_path)} if secque_cache_path.is_file() else {}
    judge_client = None
    if judge_secque:
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        if not api_key:
            raise RuntimeError("--judge-secque 需要环境变量 OPENAI_API_KEY")
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("缺少 openai 包；请先运行 安装环境.bat") from exc
        kwargs: dict[str, Any] = {"api_key": api_key}
        base_url = os.getenv("OPENAI_BASE_URL", "").strip()
        if base_url:
            kwargs["base_url"] = base_url
        judge_client = OpenAI(**kwargs)

    scored_rows: list[dict[str, Any]] = []
    for i, row in enumerate(rows, 1):
        scored = dict(row)
        suite = row.get("suite")
        correct: bool | None = None
        pred_num = gold_num = None
        grader_text = ""
        metric = ""
        if row.get("status") not in {"done", "partial"}:
            correct = False
            metric = "execution_failure"
        elif suite == "finchain":
            correct, pred_num, gold_num = finchain_fac_lite(row.get("prediction", ""), row.get("gold", ""))
            metric = "FAC-lite (5% relative tolerance)"
        elif suite == "t2":
            correct, pred_num, gold_num = t2_number_match(row.get("prediction", ""), row.get("gold", ""))
            metric = "T2 Number Match (oracle context, eps=1e-2)"
        elif suite == "secque":
            cached = cached_judges.get(str(row.get("case_id")))
            if cached:
                correct = bool(cached.get("correct"))
                grader_text = str(cached.get("grader_text") or "")
                metric = f"SECQUE LLM judge ({cached.get('judge_model') or judge_model})"
            elif judge_client is not None:
                try:
                    correct, grader_text = secque_judge(
                        str(row.get("question") or ""), str(row.get("gold") or ""),
                        str(row.get("prediction") or ""), judge_model, judge_client,
                    )
                    metric = f"SECQUE LLM judge ({judge_model})"
                    judge_row = {
                        "case_id": row.get("case_id"), "correct": correct,
                        "grader_text": grader_text, "judge_model": judge_model,
                        "judged_at": datetime.now().astimezone().isoformat(),
                    }
                    append_jsonl(secque_cache_path, judge_row)
                    cached_judges[str(row.get("case_id"))] = judge_row
                    print(f"[judge {i}/{len(rows)}] {row.get('case_id')} -> {'CORRECT' if correct else 'INCORRECT'}")
                except Exception as exc:
                    metric = f"SECQUE judge error ({judge_model})"
                    grader_text = f"{type(exc).__name__}: {exc}"
                    print(f"[judge {i}/{len(rows)}] {row.get('case_id')} -> ERROR: {grader_text}", file=sys.stderr)
            else:
                metric = "SECQUE ungraded (rerun score with --judge-secque)"
        scored["correct"] = correct
        scored["metric"] = metric
        scored["prediction_number"] = pred_num
        scored["gold_number"] = gold_num
        if grader_text:
            scored["grader_text"] = grader_text
        scored_rows.append(scored)

    scored_path = run_dir / "scored.jsonl"
    scored_path.write_text("", encoding="utf-8")
    for row in scored_rows:
        append_jsonl(scored_path, row)

    completion = [r for r in scored_rows if r.get("status") in {"done", "partial"}]
    latencies = [float(r.get("latency_sec") or 0.0) for r in scored_rows if r.get("latency_sec") is not None]
    summary: dict[str, Any] = {
        "run": run_dir.name,
        "n": len(scored_rows),
        "completion_rate_pct": 100.0 * len(completion) / len(scored_rows) if scored_rows else None,
        "median_latency_sec": _safe_median(latencies),
        "generated_at": datetime.now().astimezone().isoformat(),
        "suites": {},
    }
    for suite in ["secque", "finchain", "t2"]:
        items = [r for r in scored_rows if r.get("suite") == suite]
        if not items:
            continue
        valid = [bool(r["correct"]) for r in items if r.get("correct") is not None]
        suite_summary: dict[str, Any] = {
            "n": len(items), "scored": len(valid), "accuracy_pct": _mean_percent(valid),
            "unscored": len(items) - len(valid),
        }
        if suite == "secque":
            suite_summary["by_question_type"] = _score_groups(items, "category")
        elif suite == "finchain":
            suite_summary["by_level"] = _score_groups(items, "category")
            # domain is nested in metadata
            for x in items:
                x["_domain"] = (x.get("metadata") or {}).get("domain")
            suite_summary["by_domain"] = _score_groups(items, "_domain")
        elif suite == "t2":
            suite_summary["by_subset"] = _score_groups(items, "category")
        summary["suites"][suite] = suite_summary
    write_json(run_dir / "summary.json", summary)
    (run_dir / "summary.md").write_text(render_summary_md(summary), encoding="utf-8")
    write_failures_csv(run_dir / "failures.csv", scored_rows)
    return summary


def fmt_pct(x: Any) -> str:
    return "—" if x is None else f"{float(x):.2f}%"


def render_summary_md(summary: dict[str, Any]) -> str:
    lines = [
        f"# Benchmark summary — {summary['run']}", "",
        f"- Cases: {summary['n']}",
        f"- Completion rate: {fmt_pct(summary.get('completion_rate_pct'))}",
        f"- Median latency: {summary.get('median_latency_sec') if summary.get('median_latency_sec') is not None else '—'} s",
        "", "## Overall", "",
        "| Suite | N | Scored | Accuracy |",
        "|---|---:|---:|---:|",
    ]
    for suite, s in summary.get("suites", {}).items():
        lines.append(f"| {suite} | {s['n']} | {s['scored']} | {fmt_pct(s.get('accuracy_pct'))} |")
    for suite, s in summary.get("suites", {}).items():
        group_key = next((k for k in ("by_question_type", "by_level", "by_domain", "by_subset") if k in s), None)
        if not group_key:
            continue
        lines.extend(["", f"## {suite} — {group_key}", "", "| Group | N | Scored | Accuracy |", "|---|---:|---:|---:|"])
        for name, g in s[group_key].items():
            lines.append(f"| {name} | {g['n']} | {g['scored']} | {fmt_pct(g.get('accuracy_pct'))} |")
        if suite == "finchain" and "by_domain" in s and group_key != "by_domain":
            lines.extend(["", "### FinChain by domain", "", "| Domain | N | Scored | Accuracy |", "|---|---:|---:|---:|"])
            for name, g in s["by_domain"].items():
                lines.append(f"| {name} | {g['n']} | {g['scored']} | {fmt_pct(g.get('accuracy_pct'))} |")
    lines.extend(["", "> SECQUE 未设置 `--judge-secque` 时不会伪造字符串匹配分数；请配置 OPENAI_API_KEY 后重跑 score。", ""])
    return "\n".join(lines)


def write_failures_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = ["case_id", "suite", "category", "status", "correct", "latency_sec", "question", "gold", "prediction", "error"]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            # Unjudged SECQUE rows are not failures; they are simply unscored.
            if r.get("correct") is True or (r.get("correct") is None and r.get("status") in {"done", "partial"}):
                continue
            w.writerow({k: r.get(k, "") for k in fields})


def cmd_score(args: argparse.Namespace) -> int:
    run_dir = resolve_run_dir(args.run)
    if not run_dir.is_dir():
        print(f"[score] run not found: {run_dir}", file=sys.stderr)
        return 2
    try:
        summary = score_run(run_dir, args.judge_secque, args.judge_model)
    except Exception as exc:
        print(f"[score] FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"[score] wrote {run_dir / 'summary.md'}")
    return 0


def cmd_selftest(_: argparse.Namespace) -> int:
    checks: list[tuple[str, bool]] = []

    def check(name: str, cond: bool) -> None:
        checks.append((name, bool(cond)))

    check("parse comma", parse_number_token("$1,234.50") == 1234.5)
    check("parse negative", parse_number_token("-42.25") == -42.25)
    check("parse parentheses", parse_number_token("(1,200.00)") == -1200.0)
    check("parse million", parse_number_token("1.25 million") == 1_250_000.0)
    check("prefer FINAL_ANSWER", extract_final_number("Step 1: 10\nFINAL_ANSWER: 25.5") == 25.5)
    ok, _, _ = finchain_fac_lite("FINAL_ANSWER: 104.9", "Step 1: x=50\nStep 2: result = 100")
    check("FinChain within 5%", ok is True)
    ok, _, _ = finchain_fac_lite("FINAL_ANSWER: 105.1", "Step 1: x=50\nStep 2: result = 100")
    check("FinChain outside 5%", ok is False)
    ok, _, _ = t2_number_match("FINAL_ANSWER: 206.588", "206588")
    check("T2 scale invariant", ok is True)
    ok, _, _ = t2_number_match("FINAL_ANSWER: 100.5", "100")
    check("T2 0.5% tolerance", ok is True)
    ok, _, _ = t2_number_match("FINAL_ANSWER: 102", "100")
    check("T2 >1% fails", ok is False)
    ok, _, _ = t2_number_match("FINAL_ANSWER: 0", "0")
    check("T2 zero", ok is True)
    sse = list(parse_sse_lines(["", 'data: {"type":"done","text":"ok"}', "event: x", "data: bad"]))
    check("SSE parse", sse == [{"type": "done", "text": "ok"}])
    sample_a = _deterministic_sample([{"id": i} for i in range(50)], 10, "x")
    sample_b = _deterministic_sample([{"id": i} for i in range(50)], 10, "x")
    check("deterministic sample", sample_a == sample_b and len(sample_a) == 10)

    failed = [name for name, cond in checks if not cond]
    for name, cond in checks:
        print(f"[{'PASS' if cond else 'FAIL'}] {name}")
    if failed:
        print(f"selftest failed: {failed}", file=sys.stderr)
        return 1
    print(f"selftest PASS: {len(checks)} checks")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="衡知金融 Agent 快速 benchmark runner")
    sub = p.add_subparsers(dest="command", required=True)

    sp = sub.add_parser("prepare", help="下载 SECQUE、T² metadata 和 FinChain templates")
    sp.add_argument("--force", action="store_true", help="重新下载/覆盖 FinChain")
    sp.set_defaults(func=cmd_prepare)

    sp = sub.add_parser("doctor", help="检查衡知服务和 benchmark API")
    sp.add_argument("--server", default=DEFAULT_SERVER)
    sp.set_defaults(func=cmd_doctor)

    sp = sub.add_parser("run", help="运行 benchmark")
    sp.add_argument("--suite", choices=["all", "secque", "finchain", "t2"], default="all")
    sp.add_argument("--profile", choices=["smoke", "quick"], default="quick")
    sp.add_argument("--server", default=DEFAULT_SERVER)
    sp.add_argument("--workers", type=int, default=1, help="并发数；先用1，确认API限额后可用2-4")
    sp.add_argument("--timeout", type=float, default=DEFAULT_REQUEST_TIMEOUT, help="单题超时秒数")
    sp.add_argument("--limit", type=int, default=None, help="只跑前N题，用于调试")
    sp.add_argument("--run-id", default="", help="固定run id；重复执行可断点续跑")
    sp.add_argument("--no-resume", dest="resume", action="store_false", help="不跳过已有case")
    sp.set_defaults(resume=True, func=cmd_run)

    sp = sub.add_parser("score", help="给已有 run 评分并生成 summary")
    sp.add_argument("--run", default="latest", help="latest、run id 或目录")
    sp.add_argument("--judge-secque", action="store_true", help="用官方同款语义judge模板评SECQUE，需要OPENAI_API_KEY")
    sp.add_argument("--judge-model", default=os.getenv("SECQUE_JUDGE_MODEL", "gpt-5-mini"))
    sp.set_defaults(func=cmd_score)

    sp = sub.add_parser("selftest", help="离线自测评分器和SSE解析")
    sp.set_defaults(func=cmd_selftest)
    return p


def main(argv: list[str] | None = None) -> int:
    ensure_dirs()
    parser = build_parser()
    args = parser.parse_args(argv)
    if hasattr(args, "workers") and args.workers < 1:
        parser.error("--workers must be >= 1")
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
