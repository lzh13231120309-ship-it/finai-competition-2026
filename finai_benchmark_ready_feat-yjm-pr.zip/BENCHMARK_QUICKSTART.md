# 衡知 Benchmark 安装包

这是针对 `feat-yjm-pr` 分支准备的可直接放入仓库的评测包。

最快使用：

```bat
安装评测补丁.bat
评测.bat prepare
启动衡知.bat
评测.bat doctor
评测.bat selftest
评测.bat run --suite all --profile smoke --run-id smoke-01
评测.bat score --run smoke-01
```

详细说明见 `benchmarks/README.md`。

新增文件：
- `install_benchmark_patch.py`
- `安装评测补丁.bat`
- `评测.bat`
- `benchmarks/run_benchmarks.py`
- `benchmarks/README.md`
- `benchmarks/.gitignore`

安装器会自动修改并备份：
- `金融大赛_集成试用版/server/app.py`
- `金融大赛_集成试用版/server/agent.py`
