@echo off
chcp 65001 >nul
setlocal
set "ROOT=%~dp0"
set "PY=%ROOT%runtime\python\Scripts\python.exe"
if not exist "%PY%" (
  echo [ERROR] 未找到 %PY%
  echo 请先在仓库根目录运行 安装环境.bat
  exit /b 1
)
"%PY%" -X utf8 "%ROOT%benchmarks\run_benchmarks.py" %*
exit /b %errorlevel%
