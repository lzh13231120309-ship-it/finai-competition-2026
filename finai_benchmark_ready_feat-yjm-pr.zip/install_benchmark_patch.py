from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


class PatchError(RuntimeError):
    pass


SERVER_REL = Path("金融大赛_集成试用版") / "server"
APP_REL = SERVER_REL / "app.py"
AGENT_REL = SERVER_REL / "agent.py"
BACKUP_REL = Path("benchmarks") / "backup"


def _replace_once(text: str, old: str, new: str, label: str) -> tuple[str, bool]:
    """Apply one exact, idempotent replacement."""
    if new in text:
        return text, False
    count = text.count(old)
    if count != 1:
        raise PatchError(
            f"{label}: expected exactly one old anchor, found {count}. "
            "Your branch may have changed; do not force-apply this patch."
        )
    return text.replace(old, new, 1), True


def patch_app(text: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    old = """        'implemented_topics':[1,2,4], 'future_topics':[3,5,6,7],
        "ok": True, "version": app.version, "time": time.time(),
"""
    new = """        'implemented_topics':[1,2,4], 'future_topics':[3,5,6,7],
        'benchmark_api': True,
        "ok": True, "version": app.version, "time": time.time(),
"""
    text, changed = _replace_once(text, old, new, "app.py health marker")
    if changed:
        changes.append("app.py: /api/health 增加 benchmark_api=true")

    old = """    provider: str | None = None
    model: str | None = None
"""
    new = """    provider: str | None = None
    model: str | None = None
    benchmark_mode: bool = False
    benchmark_tools: list[str] = []
"""
    text, changed = _replace_once(text, old, new, "app.py ChatBody")
    if changed:
        changes.append("app.py: ChatBody 增加 benchmark_mode / benchmark_tools")

    old = """            async for ev in agent.run_agent(body.task_id, body.content, attachments, cancel_event):
                yield _sse(ev)
"""
    new = """            async for ev in agent.run_agent(
                body.task_id,
                body.content,
                attachments,
                cancel_event,
                benchmark_mode=body.benchmark_mode,
                benchmark_tools=body.benchmark_tools,
            ):
                yield _sse(ev)
"""
    text, changed = _replace_once(text, old, new, "app.py run_agent forwarding")
    if changed:
        changes.append("app.py: /api/chat 转发 benchmark 参数")

    return text, changes


BENCHMARK_PROMPT = r"""def build_benchmark_system_prompt(tool_names: set[str]) -> str:
    # System prompt used only by the offline benchmark harness.
    tool_note = (
        "No tools are available for this case."
        if not tool_names
        else "The only available tool for this case is calculator. Use it for arithmetic when useful."
    )
    return (
        "You are being evaluated on an offline financial benchmark. "
        "The user's question and any context included in that same message are the complete materials for this case. "
        "Do not assume or use knowledge bases, MCP, web browsing, filesystem access, skills, uploaded-file workflows, "
        "or any other source not explicitly supplied in the current message. "
        "Answer in the language of the question. Be precise with dates, units, signs, percentages, and financial definitions. "
        "If the question requests a final-answer format, follow it exactly. "
        + tool_note
    )

"""


def patch_agent(text: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    old = """FINANCIAL_NAMES=financial_agent.NAMES | research_agent.NAMES
MAX_TOOL_RESULT = 12000
"""
    new = """FINANCIAL_NAMES=financial_agent.NAMES | research_agent.NAMES
BENCHMARK_TOOL_NAMES = {"calculator"}
MAX_TOOL_RESULT = 12000
"""
    text, changed = _replace_once(text, old, new, "agent.py tool whitelist")
    if changed:
        changes.append("agent.py: 增加 benchmark 工具白名单")

    marker = "def build_system_prompt(task_id: str, financial_only: bool = False) -> str:\n"
    if "def build_benchmark_system_prompt(" not in text:
        count = text.count(marker)
        if count != 1:
            raise PatchError(
                f"agent.py benchmark prompt: expected one build_system_prompt anchor, found {count}"
            )
        text = text.replace(marker, BENCHMARK_PROMPT + marker, 1)
        changes.append("agent.py: 增加独立 benchmark system prompt")

    old = """async def run_agent(
    task_id: str, text: str, attachments: list[dict],
    cancel_event: asyncio.Event | None = None,
) -> AsyncGenerator[dict, None]:
"""
    new = """async def run_agent(
    task_id: str,
    text: str,
    attachments: list[dict],
    cancel_event: asyncio.Event | None = None,
    benchmark_mode: bool = False,
    benchmark_tools: list[str] | None = None,
) -> AsyncGenerator[dict, None]:
"""
    text, changed = _replace_once(text, old, new, "agent.py run_agent signature")
    if changed:
        changes.append("agent.py: run_agent 增加 benchmark 参数")

    old = """    # 自动命名任务
    if cfg.get("auto_title", True):
"""
    new = """    # benchmark 每题都是独立机器评测，不额外调用模型生成标题
    if not benchmark_mode and cfg.get("auto_title", True):
"""
    text, changed = _replace_once(text, old, new, "agent.py auto title")
    if changed:
        changes.append("agent.py: benchmark 禁止自动标题")

    old = """    intent=continuing_financial_intent(task_id,text)
    financial_mode = bool(intent) and (cfg.get('tools_enabled', {}) or {}).get('financial_extraction', True)
    messages = [{"role": "system", "content": build_system_prompt(task_id, financial_mode)}]
    messages += _history_messages(task_id, int(cfg.get("context_rounds", 20)))
    if messages[-1].get("role") != "user":
        messages.append({"role": "user", "content": _user_content(text, attachments,financial_mode)})
    else:
        messages[-1] = {"role": "user", "content": _user_content(text, attachments,financial_mode)}
    tools = local_tools(cfg)
    if financial_mode:
        tools = [t for t in tools if t['function']['name'] in FINANCIAL_NAMES | {'calculator'}]
"""
    new = """    requested_benchmark_tools: set[str] = set()
    if benchmark_mode:
        requested_benchmark_tools = set(benchmark_tools or [])
        unknown_benchmark_tools = requested_benchmark_tools - BENCHMARK_TOOL_NAMES
        if unknown_benchmark_tools:
            yield {
                "type": "error",
                "error": "benchmark_mode 不允许工具：" + ", ".join(sorted(unknown_benchmark_tools)),
            }
            return
        intent = None
        financial_mode = False
        messages = [{
            "role": "system",
            "content": build_benchmark_system_prompt(requested_benchmark_tools),
        }]
    else:
        intent=continuing_financial_intent(task_id,text)
        financial_mode = bool(intent) and (cfg.get('tools_enabled', {}) or {}).get('financial_extraction', True)
        messages = [{"role": "system", "content": build_system_prompt(task_id, financial_mode)}]

    messages += _history_messages(task_id, int(cfg.get("context_rounds", 20)))
    if messages[-1].get("role") != "user":
        messages.append({"role": "user", "content": _user_content(text, attachments,financial_mode)})
    else:
        messages[-1] = {"role": "user", "content": _user_content(text, attachments,financial_mode)}

    if benchmark_mode:
        tools = [
            t for t in LOCAL_TOOLS
            if t["function"]["name"] in requested_benchmark_tools
        ]
    else:
        tools = local_tools(cfg)
        if financial_mode:
            tools = [t for t in tools if t['function']['name'] in FINANCIAL_NAMES | {'calculator'}]
"""
    text, changed = _replace_once(text, old, new, "agent.py benchmark routing")
    if changed:
        changes.append("agent.py: 隔离 benchmark prompt / tools / finance routing")

    old = """    if not financial_mode and mcp_enabled and (cfg.get("tools_enabled", {}) or {}).get("mcp", True):
"""
    new = """    if not benchmark_mode and not financial_mode and mcp_enabled and (cfg.get("tools_enabled", {}) or {}).get("mcp", True):
"""
    text, changed = _replace_once(text, old, new, "agent.py MCP isolation")
    if changed:
        changes.append("agent.py: benchmark 禁止 MCP")

    old = """                temperature=float(cfg.get("temperature", 0.3)),
"""
    new = """                temperature=0.0 if benchmark_mode else float(cfg.get("temperature", 0.3)),
"""
    text, changed = _replace_once(text, old, new, "agent.py temperature")
    if changed:
        changes.append("agent.py: benchmark temperature=0")

    old = """            if not financial_mode and fname in FINANCIAL_NAMES and (cfg.get('tools_enabled',{}) or {}).get('financial_extraction',True):
"""
    new = """            if not benchmark_mode and not financial_mode and fname in FINANCIAL_NAMES and (cfg.get('tools_enabled',{}) or {}).get('financial_extraction',True):
"""
    text, changed = _replace_once(text, old, new, "agent.py financial auto-activation")
    if changed:
        changes.append("agent.py: benchmark 禁止误激活正式金融附件 workflow")

    return text, changes


def validate_python(path: Path, text: str) -> None:
    try:
        compile(text, str(path), "exec")
    except SyntaxError as exc:
        raise PatchError(f"{path}: patched file has SyntaxError: {exc}") from exc


def repo_paths(root: Path) -> tuple[Path, Path, Path]:
    root = root.resolve()
    return root / APP_REL, root / AGENT_REL, root / BACKUP_REL


def status(root: Path) -> int:
    app_path, agent_path, _ = repo_paths(root)
    missing = [p for p in (app_path, agent_path) if not p.is_file()]
    if missing:
        print("[check] FAIL: 缺少文件：")
        for p in missing:
            print(" -", p)
        return 2

    app = app_path.read_text(encoding="utf-8")
    agent = agent_path.read_text(encoding="utf-8")
    checks = {
        "app benchmark_api": "'benchmark_api': True" in app,
        "app ChatBody": "benchmark_mode: bool = False" in app and "benchmark_tools: list[str] = []" in app,
        "app forwarding": "benchmark_mode=body.benchmark_mode" in app,
        "agent whitelist": 'BENCHMARK_TOOL_NAMES = {"calculator"}' in agent,
        "agent prompt": "def build_benchmark_system_prompt(" in agent,
        "agent signature": "benchmark_mode: bool = False" in agent and "benchmark_tools: list[str] | None = None" in agent,
        "agent no MCP": "if not benchmark_mode and not financial_mode and mcp_enabled" in agent,
        "agent temp=0": "temperature=0.0 if benchmark_mode else" in agent,
        "agent no finance auto-route": "if not benchmark_mode and not financial_mode and fname in FINANCIAL_NAMES" in agent,
    }
    for name, ok in checks.items():
        print(f"[{'PASS' if ok else 'MISS'}] {name}")
    return 0 if all(checks.values()) else 1


def apply(root: Path) -> int:
    app_path, agent_path, backup_dir = repo_paths(root)
    if not app_path.is_file() or not agent_path.is_file():
        raise PatchError(
            "未找到 feat-yjm-pr 当前目录结构。请把本安装器放在仓库根目录运行，"
            "或使用 --root 指向 finai-competition-2026。"
        )

    app_before = app_path.read_text(encoding="utf-8")
    agent_before = agent_path.read_text(encoding="utf-8")

    app_after, app_changes = patch_app(app_before)
    agent_after, agent_changes = patch_agent(agent_before)

    validate_python(app_path, app_after)
    validate_python(agent_path, agent_after)

    all_changes = app_changes + agent_changes
    if not all_changes:
        print("[apply] 已经是 benchmark 版本，无需重复修改。")
        return status(root)

    backup_dir.mkdir(parents=True, exist_ok=True)
    app_backup = backup_dir / "app.py.pre-benchmark.bak"
    agent_backup = backup_dir / "agent.py.pre-benchmark.bak"
    if not app_backup.exists():
        shutil.copy2(app_path, app_backup)
    if not agent_backup.exists():
        shutil.copy2(agent_path, agent_backup)

    app_path.write_text(app_after, encoding="utf-8", newline="\n")
    agent_path.write_text(agent_after, encoding="utf-8", newline="\n")

    print("[apply] 完成：")
    for change in all_changes:
        print(" -", change)
    print("[apply] 原文件备份在：", backup_dir)
    print("[apply] 下一步：启动衡知后运行 `评测.bat doctor`。")
    return status(root)


def restore(root: Path) -> int:
    app_path, agent_path, backup_dir = repo_paths(root)
    app_backup = backup_dir / "app.py.pre-benchmark.bak"
    agent_backup = backup_dir / "agent.py.pre-benchmark.bak"
    if not app_backup.is_file() or not agent_backup.is_file():
        raise PatchError(f"没有找到完整备份：{backup_dir}")
    shutil.copy2(app_backup, app_path)
    shutil.copy2(agent_backup, agent_path)
    print("[restore] 已恢复 app.py / agent.py 到打 benchmark 补丁前版本。")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="为 feat-yjm-pr 安装衡知 benchmark_mode 小补丁")
    p.add_argument("--root", default=str(Path(__file__).resolve().parent),
                   help="finai-competition-2026 仓库根目录；默认是本脚本所在目录")
    group = p.add_mutually_exclusive_group()
    group.add_argument("--check", action="store_true", help="只检查补丁状态，不修改")
    group.add_argument("--restore", action="store_true", help="从 benchmarks/backup 恢复")
    return p


def main() -> int:
    args = build_parser().parse_args()
    root = Path(args.root)
    try:
        if args.check:
            return status(root)
        if args.restore:
            return restore(root)
        return apply(root)
    except PatchError as exc:
        print(f"[patch] FAIL: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
